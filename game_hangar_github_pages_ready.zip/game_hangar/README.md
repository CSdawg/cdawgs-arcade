# Game Hangar

This is a GitHub Pages ready static website for hosting HTML games.

## Folder structure

```text
game_hangar/
  index.html
  style.css
  games/
    runway-rush/
      index.html
```

## How to publish on GitHub Pages

1. Create a new public GitHub repository.
2. Upload everything inside this `game_hangar` folder to the repository.
3. Go to the repository on GitHub.
4. Open **Settings**.
5. Open **Pages** from the left sidebar.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Set the branch to `main` and the folder to `/root`.
8. Click **Save**.
9. After GitHub finishes deploying, your site will be available at:

```text
https://YOUR_USERNAME.github.io/YOUR_REPOSITORY_NAME/
```

## How to add another game

1. Add a new folder inside `games/`.

Example:

```text
games/new-game/index.html
```

2. Add another game card to the homepage `index.html`.

Example:

```html
<a class="game-card" href="games/new-game/">
  <div class="card-art placeholder-art">
    <span>▶</span>
  </div>
  <div class="card-content">
    <p class="tag">Arcade</p>
    <h3>New Game</h3>
    <p>A short description of the game.</p>
    <span class="play-button">Play Game</span>
  </div>
</a>
```
